import type { Express, Request, Response } from "express";
import { setupAuth } from "./auth";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertCustomerSchema, 
  insertVehicleSchema, 
  insertQuoteSchema, 
  insertServiceSchema,
  serviceUpdateSchema 
} from "@shared/schema";
import multer from "multer";
import { z } from "zod";

// Configure memory storage for file uploads
const memoryStorage = multer.memoryStorage();
const upload = multer({
  storage: memoryStorage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
    files: 5 // max 5 files
  }
});

// Middleware to validate session is authenticated
function isAuthenticated(req: Request, res: Response, next: any) {
  if (req.isAuthenticated()) return next();
  res.status(401).json({ message: "Unauthorized" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Sets up /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // Customer routes
  app.get("/api/customers", isAuthenticated, async (req, res) => {
    try {
      const customers = await storage.getAllCustomers();
      res.json(customers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  app.get("/api/customers/:id", isAuthenticated, async (req, res) => {
    try {
      const customer = await storage.getCustomer(parseInt(req.params.id));
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer" });
    }
  });

  app.post("/api/customers", isAuthenticated, async (req, res) => {
    try {
      const customerData = insertCustomerSchema.parse(req.body);
      const customer = await storage.createCustomer(customerData);
      res.status(201).json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid customer data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create customer" });
    }
  });

  app.put("/api/customers/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const customerData = insertCustomerSchema.partial().parse(req.body);
      const customer = await storage.updateCustomer(id, customerData);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      res.json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid customer data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update customer" });
    }
  });

  app.delete("/api/customers/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteCustomer(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // Vehicle routes
  app.get("/api/vehicles", isAuthenticated, async (req, res) => {
    try {
      const vehicles = await storage.getAllVehicles();
      res.json(vehicles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch vehicles" });
    }
  });

  app.get("/api/vehicles/:id", isAuthenticated, async (req, res) => {
    try {
      const vehicle = await storage.getVehicle(parseInt(req.params.id));
      if (!vehicle) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      res.json(vehicle);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch vehicle" });
    }
  });

  app.get("/api/customers/:customerId/vehicles", isAuthenticated, async (req, res) => {
    try {
      const customerId = parseInt(req.params.customerId);
      const vehicles = await storage.getVehiclesByCustomerId(customerId);
      res.json(vehicles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer vehicles" });
    }
  });

  app.post("/api/vehicles", isAuthenticated, async (req, res) => {
    try {
      const vehicleData = insertVehicleSchema.parse(req.body);
      const vehicle = await storage.createVehicle(vehicleData);
      res.status(201).json(vehicle);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid vehicle data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create vehicle" });
    }
  });

  app.put("/api/vehicles/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const vehicleData = insertVehicleSchema.partial().parse(req.body);
      const vehicle = await storage.updateVehicle(id, vehicleData);
      
      if (!vehicle) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      res.json(vehicle);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid vehicle data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update vehicle" });
    }
  });

  app.delete("/api/vehicles/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteVehicle(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete vehicle" });
    }
  });

  // Quote routes
  app.get("/api/quotes", isAuthenticated, async (req, res) => {
    try {
      const quotes = await storage.getAllQuotes();
      res.json(quotes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quotes" });
    }
  });

  app.get("/api/quotes/:id", isAuthenticated, async (req, res) => {
    try {
      const quote = await storage.getQuote(parseInt(req.params.id));
      if (!quote) {
        return res.status(404).json({ message: "Quote not found" });
      }
      res.json(quote);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quote" });
    }
  });

  app.get("/api/customers/:customerId/quotes", isAuthenticated, async (req, res) => {
    try {
      const customerId = parseInt(req.params.customerId);
      const quotes = await storage.getQuotesByCustomerId(customerId);
      res.json(quotes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer quotes" });
    }
  });

  app.post("/api/quotes", isAuthenticated, async (req, res) => {
    try {
      console.log("Received quote data:", JSON.stringify(req.body));
      
      // Converta explicitamente os campos numéricos se necessário
      const data = {
        ...req.body,
        customerId: Number(req.body.customerId),
        vehicleId: Number(req.body.vehicleId),
        total: Number(req.body.total),
        // Converta items para JSON se for uma string
        items: typeof req.body.items === 'string' ? JSON.parse(req.body.items) : req.body.items
      };
      
      const quoteData = insertQuoteSchema.parse(data);
      console.log("Parsed quote data:", JSON.stringify(quoteData));
      
      const quote = await storage.createQuote(quoteData);
      res.status(201).json(quote);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("Zod validation error:", error.errors);
        return res.status(400).json({ message: "Invalid quote data", errors: error.errors });
      }
      console.error("Server error creating quote:", error);
      res.status(500).json({ message: "Failed to create quote: " + (error as Error).message });
    }
  });

  app.patch("/api/quotes/:id/status", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !['pending', 'approved', 'rejected'].includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }
      
      const quote = await storage.updateQuoteStatus(id, status);
      
      if (!quote) {
        return res.status(404).json({ message: "Quote not found" });
      }
      
      res.json(quote);
    } catch (error) {
      res.status(500).json({ message: "Failed to update quote status" });
    }
  });

  app.put("/api/quotes/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      console.log("Updating quote data:", JSON.stringify(req.body));
      
      // Converta explicitamente os campos numéricos se necessário
      const data = {
        ...req.body,
        customerId: Number(req.body.customerId),
        vehicleId: Number(req.body.vehicleId),
        total: Number(req.body.total),
        // Converta items para JSON se for uma string
        items: typeof req.body.items === 'string' ? JSON.parse(req.body.items) : req.body.items
      };
      
      const quoteData = insertQuoteSchema.partial().parse(data);
      console.log("Parsed quote update data:", JSON.stringify(quoteData));
      
      const quote = await storage.updateQuote(id, quoteData);
      
      if (!quote) {
        return res.status(404).json({ message: "Quote not found" });
      }
      
      res.json(quote);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("Zod validation error:", error.errors);
        return res.status(400).json({ message: "Invalid quote data", errors: error.errors });
      }
      console.error("Server error updating quote:", error);
      res.status(500).json({ message: "Failed to update quote: " + (error as Error).message });
    }
  });

  app.delete("/api/quotes/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteQuote(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Quote not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete quote" });
    }
  });

  // Service routes
  app.get("/api/services", isAuthenticated, async (req, res) => {
    try {
      const services = await storage.getAllServices();
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch services" });
    }
  });

  app.get("/api/services/:id", isAuthenticated, async (req, res) => {
    try {
      const service = await storage.getService(parseInt(req.params.id));
      if (!service) {
        return res.status(404).json({ message: "Service not found" });
      }
      res.json(service);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch service" });
    }
  });

  app.get("/api/customers/:customerId/services", isAuthenticated, async (req, res) => {
    try {
      const customerId = parseInt(req.params.customerId);
      const services = await storage.getServicesByCustomerId(customerId);
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer services" });
    }
  });

  app.post("/api/services", isAuthenticated, upload.array('beforePhotos', 5), async (req, res) => {
    try {
      // Get the files if any were uploaded
      const files = req.files as Express.Multer.File[] | undefined;
      
      // Prepare photo data (would be file paths in a real system, here we'll use the file names)
      const beforePhotos = files?.map(file => ({
        filename: file.originalname,
        mimetype: file.mimetype,
        size: file.size,
        // In a real system, we would save the file and store its path or reference
        data: file.buffer.toString('base64').substring(0, 100) + '...' // truncate for memory efficiency
      })) || [];
      
      // Parse and validate the form data
      const serviceData = insertServiceSchema.parse({
        ...req.body,
        quoteId: parseInt(req.body.quoteId),
        customerId: parseInt(req.body.customerId),
        vehicleId: parseInt(req.body.vehicleId),
        odometer: parseInt(req.body.odometer),
        itemsLeft: req.body.itemsLeft ? JSON.parse(req.body.itemsLeft) : [],
        beforePhotos: beforePhotos.length > 0 ? beforePhotos : undefined
      });
      
      const service = await storage.createService(serviceData);
      res.status(201).json(service);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid service data", errors: error.errors });
      }
      console.error("Service creation error:", error);
      res.status(500).json({ message: "Failed to create service" });
    }
  });

  app.patch("/api/services/:id", isAuthenticated, upload.array('afterPhotos', 5), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the files if any were uploaded
      const files = req.files as Express.Multer.File[] | undefined;
      
      // Prepare photo data
      const afterPhotos = files?.map(file => ({
        filename: file.originalname,
        mimetype: file.mimetype,
        size: file.size,
        data: file.buffer.toString('base64').substring(0, 100) + '...' // truncate for memory efficiency
      })) || [];
      
      // Prepare service update data
      const updateData: any = {
        ...req.body
      };
      
      if (afterPhotos.length > 0) {
        updateData.afterPhotos = afterPhotos;
      }
      
      // Validate the update data
      const serviceUpdateData = serviceUpdateSchema.partial().parse(updateData);
      
      // Update the service
      const service = await storage.updateService(id, serviceUpdateData);
      
      if (!service) {
        return res.status(404).json({ message: "Service not found" });
      }
      
      res.json(service);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid service update data", errors: error.errors });
      }
      console.error("Service update error:", error);
      res.status(500).json({ message: "Failed to update service" });
    }
  });

  app.delete("/api/services/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteService(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Service not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete service" });
    }
  });

  // Dashboard statistics
  app.get("/api/dashboard/stats", isAuthenticated, async (req, res) => {
    try {
      const customers = await storage.getAllCustomers();
      const vehicles = await storage.getAllVehicles();
      const quotes = await storage.getAllQuotes();
      const services = await storage.getAllServices();
      
      const pendingQuotes = quotes.filter(q => q.status === 'pending');
      const inProgressServices = services.filter(s => s.status === 'in_progress');
      
      const stats = {
        customerCount: customers.length,
        vehicleCount: vehicles.length,
        pendingQuoteCount: pendingQuotes.length,
        activeServiceCount: inProgressServices.length,
        recentServices: inProgressServices.slice(0, 5),
        recentQuotes: quotes.slice(0, 5)
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard statistics" });
    }
  });

  const httpServer = createServer(app);
  
  return httpServer;
}
