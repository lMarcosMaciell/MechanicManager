import { pgTable, text, serial, integer, boolean, date, timestamp, numeric, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Customer schema
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  birthDate: date("birth_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCustomerSchema = createInsertSchema(customers).pick({
  name: true,
  address: true,
  phone: true,
  birthDate: true,
});

// Vehicle schema
export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  manufacturer: text("manufacturer").notNull(),
  model: text("model").notNull(),
  year: integer("year").notNull(),
  licensePlate: text("license_plate").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertVehicleSchema = createInsertSchema(vehicles).pick({
  customerId: true,
  manufacturer: true,
  model: true,
  year: true,
  licensePlate: true,
});

// Quote schema
export const quotes = pgTable("quotes", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  vehicleId: integer("vehicle_id").notNull(),
  date: date("date").notNull(),
  validUntil: date("valid_until").notNull(),
  status: text("status").notNull(), // pending, approved, rejected
  total: numeric("total", { precision: 10, scale: 2 }).notNull(),
  items: jsonb("items").notNull(), // {services: [], parts: []}
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertQuoteSchema = createInsertSchema(quotes).pick({
  customerId: true,
  vehicleId: true,
  date: true,
  validUntil: true,
  status: true,
  total: true,
  items: true,
  notes: true,
});

// Service schema
export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  quoteId: integer("quote_id").notNull(),
  customerId: integer("customer_id").notNull(),
  vehicleId: integer("vehicle_id").notNull(),
  status: text("status").notNull(), // in_progress, waiting_parts, completed
  startDate: date("start_date").notNull(),
  estimatedEndDate: date("estimated_end_date").notNull(),
  actualEndDate: date("actual_end_date"),
  initialDescription: text("initial_description").notNull(),
  odometer: integer("odometer").notNull(),
  fuelLevel: text("fuel_level").notNull(),
  itemsLeft: jsonb("items_left"),
  beforePhotos: jsonb("before_photos"),
  afterPhotos: jsonb("after_photos"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertServiceSchema = createInsertSchema(services).pick({
  quoteId: true,
  customerId: true,
  vehicleId: true,
  status: true,
  startDate: true,
  estimatedEndDate: true,
  initialDescription: true,
  odometer: true,
  fuelLevel: true,
  itemsLeft: true,
  beforePhotos: true,
  notes: true,
});

// Service Update schema
export const serviceUpdateSchema = createInsertSchema(services).pick({
  status: true,
  actualEndDate: true,
  afterPhotos: true,
  notes: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

export type InsertVehicle = z.infer<typeof insertVehicleSchema>;
export type Vehicle = typeof vehicles.$inferSelect;

export type InsertQuote = z.infer<typeof insertQuoteSchema>;
export type Quote = typeof quotes.$inferSelect;

export type InsertService = z.infer<typeof insertServiceSchema>;
export type Service = typeof services.$inferSelect;
export type UpdateService = z.infer<typeof serviceUpdateSchema>;

// Quote Item type definition (for TypeScript)
export type QuoteItem = {
  id: string;
  description: string;
  quantity: number;
  price: number;
  type: 'service' | 'part';
};
