import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string | null | undefined): string {
  if (!date) return '';
  
  try {
    const dateObj = typeof date === 'string' ? parseISO(date) : date;
    return format(dateObj, 'dd/MM/yyyy', { locale: ptBR });
  } catch (error) {
    console.error('Error formatting date:', error);
    return '';
  }
}

export function formatCurrency(value: number | string | null | undefined): string {
  if (value === null || value === undefined) return '';
  
  const numValue = typeof value === 'string' ? parseFloat(value) : value;
  
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(numValue);
}

// Format a phone number as (XX) XXXXX-XXXX
export function formatPhoneNumber(phone: string): string {
  if (!phone) return '';
  
  // Remove any non-digit characters
  const digits = phone.replace(/\D/g, '');
  
  if (digits.length <= 10) {
    // Format as (XX) XXXX-XXXX for landlines
    return digits.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
  } else {
    // Format as (XX) XXXXX-XXXX for mobile
    return digits.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  }
}

// Function to generate random IDs
export function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}

// Format a license plate
export function formatLicensePlate(plate: string): string {
  if (!plate) return '';
  
  // Standardize to uppercase and remove any non-alphanumeric characters
  const clean = plate.toUpperCase().replace(/[^A-Z0-9]/g, '');
  
  // Format as XXX-0000 (old format) or XXX0X00 (Mercosul format)
  if (clean.length === 7 && /^[A-Z]{3}\d[A-Z0-9]\d\d$/.test(clean)) {
    // Mercosul format
    return clean;
  } else if (clean.length === 7 && /^[A-Z]{3}\d{4}$/.test(clean)) {
    // Old format
    return `${clean.substring(0, 3)}-${clean.substring(3)}`;
  }
  
  // Return as is if it doesn't match expected formats
  return plate;
}
