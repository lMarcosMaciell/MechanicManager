import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Service, insertServiceSchema, serviceUpdateSchema, Customer, Vehicle, Quote } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2, Calendar } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { FileUpload } from "@/components/ui/file-upload";
import { formatDate } from "@/lib/utils";

// Service form schema
const serviceFormSchema = insertServiceSchema.extend({
  quoteId: z.number({
    required_error: "Por favor selecione um orçamento",
    invalid_type_error: "Por favor selecione um orçamento válido"
  }),
  customerId: z.number({
    required_error: "Por favor selecione um cliente",
    invalid_type_error: "Por favor selecione um cliente válido"
  }),
  vehicleId: z.number({
    required_error: "Por favor selecione um veículo",
    invalid_type_error: "Por favor selecione um veículo válido"
  }),
  startDate: z.string(),
  estimatedEndDate: z.string(),
  initialDescription: z.string().min(5, "A descrição deve ter pelo menos 5 caracteres"),
  odometer: z.number().min(0, "O valor do odômetro deve ser maior ou igual a zero"),
  fuelLevel: z.string(),
  itemsLeft: z.array(z.string()).optional(),
  beforePhotos: z.any().optional(),
  notes: z.string().optional(),
});

// Service update schema
const serviceUpdateFormSchema = serviceUpdateSchema.extend({
  status: z.string(),
  notes: z.string().optional(),
  afterPhotos: z.any().optional(),
});

// Fuel level options
const fuelLevels = [
  { value: "empty", label: "Vazio" },
  { value: "quarter", label: "1/4" },
  { value: "half", label: "1/2" },
  { value: "three_quarters", label: "3/4" },
  { value: "full", label: "Cheio" },
];

// Common items left in vehicle
const commonItems = [
  { id: "manual", label: "Manual" },
  { id: "spare_tire", label: "Estepe" },
  { id: "jack", label: "Macaco" },
  { id: "tools", label: "Ferramentas" },
  { id: "floor_mats", label: "Tapetes" },
];

type ServiceFormProps = {
  service?: Service | null;
  preSelectedQuoteId?: number | null;
  preSelectedVehicleId?: number | null;
  preSelectedCustomerId?: number | null;
  readOnly?: boolean;
  isUpdate?: boolean;
  onSuccess: () => void;
};

export default function ServiceForm({ 
  service, 
  preSelectedQuoteId, 
  preSelectedVehicleId, 
  preSelectedCustomerId, 
  readOnly = false,
  isUpdate = false,
  onSuccess 
}: ServiceFormProps) {
  const { toast } = useToast();
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | undefined>(
    service?.customerId || preSelectedCustomerId || undefined
  );
  const [beforePhotosFiles, setBeforePhotosFiles] = useState<File[]>([]);
  const [afterPhotosFiles, setAfterPhotosFiles] = useState<File[]>([]);
  const [selectedQuoteId, setSelectedQuoteId] = useState<number | undefined>(
    service?.quoteId || preSelectedQuoteId || undefined
  );

  // Fetch customers
  const { data: customers } = useQuery<Customer[]>({
    queryKey: ['/api/customers'],
  });

  // Fetch vehicles
  const { data: vehicles } = useQuery<Vehicle[]>({
    queryKey: ['/api/vehicles'],
  });

  // Fetch quotes
  const { data: quotes } = useQuery<Quote[]>({
    queryKey: ['/api/quotes'],
    select: data => data.filter(quote => quote.status === 'approved'),
  });

  // Filter customer vehicles
  const customerVehicles = vehicles?.filter(vehicle => 
    vehicle.customerId === selectedCustomerId
  ) || [];

  // Filter customer quotes
  const customerQuotes = quotes?.filter(quote => 
    quote.customerId === selectedCustomerId && quote.status === 'approved'
  ) || [];

  // Initialize form for create
  const form = useForm<z.infer<typeof serviceFormSchema>>({
    resolver: zodResolver(serviceFormSchema),
    defaultValues: {
      quoteId: service?.quoteId || preSelectedQuoteId || 0,
      customerId: service?.customerId || preSelectedCustomerId || 0,
      vehicleId: service?.vehicleId || preSelectedVehicleId || 0,
      startDate: service?.startDate 
        ? new Date(service.startDate).toISOString().split('T')[0] 
        : new Date().toISOString().split('T')[0],
      estimatedEndDate: service?.estimatedEndDate 
        ? new Date(service.estimatedEndDate).toISOString().split('T')[0] 
        : new Date(new Date().setDate(new Date().getDate() + 3)).toISOString().split('T')[0],
      status: service?.status || "in_progress",
      initialDescription: service?.initialDescription || "",
      odometer: service?.odometer || 0,
      fuelLevel: service?.fuelLevel || "half",
      itemsLeft: Array.isArray(service?.itemsLeft) ? service.itemsLeft : [],
      notes: service?.notes || "",
    },
  });

  // Initialize form for update
  const updateForm = useForm<z.infer<typeof serviceUpdateFormSchema>>({
    resolver: zodResolver(serviceUpdateFormSchema),
    defaultValues: {
      status: service?.status || "in_progress",
      notes: service?.notes || "",
    },
  });

  // Create or update mutation
  const createMutation = useMutation({
    mutationFn: async (values: z.infer<typeof serviceFormSchema>) => {
      // Create FormData for file upload
      const formData = new FormData();
      
      // Add all form fields
      Object.entries(values).forEach(([key, value]) => {
        if (key === 'itemsLeft' && Array.isArray(value)) {
          formData.append(key, JSON.stringify(value));
        } else if (key !== 'beforePhotos') {
          formData.append(key, String(value));
        }
      });
      
      // Add before photos if any
      beforePhotosFiles.forEach(file => {
        formData.append('beforePhotos', file);
      });
      
      // Create new service
      const res = await fetch('/api/services', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(errorText || res.statusText);
      }
      
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Serviço criado",
        description: "Serviço iniciado com sucesso",
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: `Não foi possível criar o serviço: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update service mutation
  const updateMutation = useMutation({
    mutationFn: async (values: z.infer<typeof serviceUpdateFormSchema>) => {
      if (!service) throw new Error("Serviço não encontrado");
      
      // Create FormData for file upload
      const formData = new FormData();
      
      // Add all form fields
      Object.entries(values).forEach(([key, value]) => {
        if (key !== 'afterPhotos') {
          formData.append(key, String(value));
        }
      });
      
      // Add after photos if any
      afterPhotosFiles.forEach(file => {
        formData.append('afterPhotos', file);
      });
      
      // Update service
      const res = await fetch(`/api/services/${service.id}`, {
        method: 'PATCH',
        body: formData,
        credentials: 'include',
      });
      
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(errorText || res.statusText);
      }
      
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Serviço atualizado",
        description: "Serviço atualizado com sucesso",
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: `Não foi possível atualizar o serviço: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Auto-select vehicle and customer based on selected quote
  useEffect(() => {
    if (selectedQuoteId && quotes) {
      const selectedQuote = quotes.find(q => q.id === selectedQuoteId);
      if (selectedQuote) {
        form.setValue('customerId', selectedQuote.customerId);
        form.setValue('vehicleId', selectedQuote.vehicleId);
        setSelectedCustomerId(selectedQuote.customerId);
      }
    }
  }, [selectedQuoteId, quotes, form]);

  const onSubmit = (values: z.infer<typeof serviceFormSchema>) => {
    createMutation.mutate(values);
  };

  const onUpdateSubmit = (values: z.infer<typeof serviceUpdateFormSchema>) => {
    updateMutation.mutate(values);
  };

  if (readOnly) {
    // Read-only service view
    const customer = customers?.find(c => c.id === service?.customerId);
    const vehicle = vehicles?.find(v => v.id === service?.vehicleId);
    const quote = quotes?.find(q => q.id === service?.quoteId);
    
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h3 className="text-sm font-medium text-gray-500">Cliente</h3>
            <p className="text-lg">{customer?.name || "Cliente não encontrado"}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Veículo</h3>
            <p className="text-lg">
              {vehicle 
                ? `${vehicle.manufacturer} ${vehicle.model} (${vehicle.licensePlate})` 
                : "Veículo não encontrado"}
            </p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Orçamento</h3>
            <p className="text-lg">#{quote?.id || "N/A"}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Status</h3>
            <p className="text-lg">
              {service?.status === 'in_progress' && "Em Andamento"}
              {service?.status === 'waiting_parts' && "Aguardando Peças"}
              {service?.status === 'completed' && "Finalizado"}
              {service?.status === 'paused' && "Pausado"}
            </p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Data de Entrada</h3>
            <p className="text-lg">{formatDate(service?.startDate)}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Previsão de Entrega</h3>
            <p className="text-lg">{formatDate(service?.estimatedEndDate)}</p>
          </div>
          {service?.actualEndDate && (
            <div>
              <h3 className="text-sm font-medium text-gray-500">Data de Conclusão</h3>
              <p className="text-lg">{formatDate(service.actualEndDate)}</p>
            </div>
          )}
        </div>
        
        <Separator />
        
        <div>
          <h3 className="text-sm font-medium text-gray-500 mb-1">Descrição Inicial</h3>
          <p className="text-sm">{service?.initialDescription}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-1">Quilometragem</h3>
            <p className="text-lg">{service?.odometer} km</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-1">Nível de Combustível</h3>
            <p className="text-lg">
              {service?.fuelLevel === 'empty' && "Vazio"}
              {service?.fuelLevel === 'quarter' && "1/4"}
              {service?.fuelLevel === 'half' && "1/2"}
              {service?.fuelLevel === 'three_quarters' && "3/4"}
              {service?.fuelLevel === 'full' && "Cheio"}
            </p>
          </div>
        </div>
        
        {service?.itemsLeft && Array.isArray(service.itemsLeft) && service.itemsLeft.length > 0 && (
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-1">Itens Deixados no Veículo</h3>
            <div className="flex flex-wrap gap-2">
              {service.itemsLeft.map(item => (
                <span key={item} className="px-2 py-1 rounded-full text-xs bg-gray-100">
                  {item}
                </span>
              ))}
            </div>
          </div>
        )}
        
        {service?.beforePhotos && Array.isArray(service.beforePhotos) && service.beforePhotos.length > 0 && (
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-2">Fotos do Veículo (Antes)</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {service.beforePhotos.map((photo, index) => (
                <div key={index} className="border rounded-md overflow-hidden h-24">
                  <div className="bg-gray-100 h-full flex items-center justify-center">
                    <p className="text-xs text-gray-500">Foto {index + 1}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {service?.afterPhotos && Array.isArray(service.afterPhotos) && service.afterPhotos.length > 0 && (
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-2">Fotos do Veículo (Depois)</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {service.afterPhotos.map((photo, index) => (
                <div key={index} className="border rounded-md overflow-hidden h-24">
                  <div className="bg-gray-100 h-full flex items-center justify-center">
                    <p className="text-xs text-gray-500">Foto {index + 1}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {service?.notes && (
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-1">Observações</h3>
            <p className="text-sm">{service.notes}</p>
          </div>
        )}
        
        <div className="flex justify-end">
          <Button type="button" onClick={onSuccess}>
            Fechar
          </Button>
        </div>
      </div>
    );
  }

  if (isUpdate) {
    // Update form
    return (
      <Form {...updateForm}>
        <form onSubmit={updateForm.handleSubmit(onUpdateSubmit)} className="space-y-6">
          <FormField
            control={updateForm.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status do Serviço*</FormLabel>
                <Select 
                  value={field.value} 
                  onValueChange={field.onChange}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="in_progress">Em Andamento</SelectItem>
                    <SelectItem value="waiting_parts">Aguardando Peças</SelectItem>
                    <SelectItem value="paused">Pausado</SelectItem>
                    <SelectItem value="completed">Finalizado</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Fotos do Veículo (Depois)</h3>
            <FileUpload
              onChange={setAfterPhotosFiles}
              maxFiles={5}
              acceptedFileTypes="image/*"
              maxSizeInMB={5}
            />
          </div>

          <FormField
            control={updateForm.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Observações</FormLabel>
                <FormControl>
                  <Textarea placeholder="Detalhes adicionais sobre o serviço" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={onSuccess}
              disabled={updateMutation.isPending}
            >
              Cancelar
            </Button>
            <Button type="submit" disabled={updateMutation.isPending}>
              {updateMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>Atualizar Serviço</>
              )}
            </Button>
          </div>
        </form>
      </Form>
    );
  }

  // Create form
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="quoteId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Orçamento Aprovado*</FormLabel>
                <Select 
                  value={field.value ? field.value.toString() : ""} 
                  onValueChange={(value) => {
                    const quoteId = parseInt(value);
                    field.onChange(quoteId);
                    setSelectedQuoteId(quoteId);
                  }}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um orçamento" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {quotes && quotes
                      .filter(q => q.status === 'approved')
                      .map(quote => {
                        const customer = customers?.find(c => c.id === quote.customerId);
                        const vehicle = vehicles?.find(v => v.id === quote.vehicleId);
                        const label = `Orç. #${quote.id} - ${customer?.name || 'Cliente'} (${vehicle ? `${vehicle.manufacturer} ${vehicle.model}` : 'Veículo'})`;
                        
                        return (
                          <SelectItem key={quote.id} value={quote.id.toString()}>
                            {label}
                          </SelectItem>
                        );
                      })}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status Inicial*</FormLabel>
                <Select 
                  value={field.value} 
                  onValueChange={field.onChange}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="in_progress">Em Andamento</SelectItem>
                    <SelectItem value="waiting_parts">Aguardando Peças</SelectItem>
                    <SelectItem value="paused">Pausado</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="startDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Data de Entrada*</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="estimatedEndDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Previsão de Entrega*</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">Condições do Veículo na Entrada</h3>
          <Card>
            <CardContent className="p-4 space-y-4">
              <FormField
                control={form.control}
                name="initialDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Descrição do Estado*</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Descreva o estado atual do veículo" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="odometer"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quilometragem*</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="0"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="fuelLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nível de Combustível*</FormLabel>
                      <Select 
                        value={field.value} 
                        onValueChange={field.onChange}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o nível" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {fuelLevels.map(level => (
                            <SelectItem key={level.value} value={level.value}>
                              {level.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Fotos do Veículo (Antes)</h4>
                <FileUpload
                  onChange={setBeforePhotosFiles}
                  maxFiles={5}
                  acceptedFileTypes="image/*"
                  maxSizeInMB={5}
                />
              </div>

              <div>
                <FormField
                  control={form.control}
                  name="itemsLeft"
                  render={() => (
                    <FormItem>
                      <div className="mb-2">
                        <FormLabel>Itens Deixados no Veículo</FormLabel>
                      </div>
                      <div className="flex flex-wrap gap-4">
                        {commonItems.map((item) => (
                          <FormField
                            key={item.id}
                            control={form.control}
                            name="itemsLeft"
                            render={({ field }) => {
                              return (
                                <FormItem
                                  key={item.id}
                                  className="flex flex-row items-start space-x-2 space-y-0"
                                >
                                  <FormControl>
                                    <Checkbox
                                      checked={field.value?.includes(item.id)}
                                      onCheckedChange={(checked) => {
                                        const currentValue = field.value || [];
                                        if (checked) {
                                          field.onChange([...currentValue, item.id]);
                                        } else {
                                          field.onChange(
                                            currentValue.filter((value) => value !== item.id)
                                          );
                                        }
                                      }}
                                    />
                                  </FormControl>
                                  <FormLabel className="font-normal cursor-pointer">
                                    {item.label}
                                  </FormLabel>
                                </FormItem>
                              );
                            }}
                          />
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Observações</FormLabel>
              <FormControl>
                <Textarea placeholder="Detalhes adicionais sobre o serviço" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-2">
          <Button
            type="button"
            variant="outline"
            onClick={onSuccess}
            disabled={createMutation.isPending}
          >
            Cancelar
          </Button>
          <Button type="submit" disabled={createMutation.isPending}>
            {createMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Salvando...
              </>
            ) : (
              <>Iniciar Serviço</>
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}
