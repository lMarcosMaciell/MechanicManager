import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Vehicle, insertVehicleSchema, Customer } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Create a schema for vehicle form with validation
const vehicleFormSchema = insertVehicleSchema.extend({
  customerId: z.number({
    required_error: "Por favor selecione um cliente",
    invalid_type_error: "Por favor selecione um cliente válido"
  }),
  manufacturer: z.string().min(2, "O fabricante deve ter pelo menos 2 caracteres"),
  model: z.string().min(1, "O modelo deve ser informado"),
  year: z.number().min(1900, "O ano deve ser maior que 1900").max(new Date().getFullYear() + 1, `O ano deve ser no máximo ${new Date().getFullYear() + 1}`),
  licensePlate: z.string().min(5, "A placa deve ter pelo menos 5 caracteres"),
});

// Common manufacturers list
const manufacturers = [
  "Chevrolet",
  "Fiat",
  "Ford",
  "Honda",
  "Hyundai",
  "Jeep",
  "Nissan",
  "Renault",
  "Toyota",
  "Volkswagen",
  "BMW",
  "Mercedes-Benz",
  "Audi",
  "Outro"
];

type VehicleFormProps = {
  vehicle?: Vehicle | null;
  preSelectedCustomerId?: number | null;
  onSuccess: () => void;
};

export default function VehicleForm({ vehicle, preSelectedCustomerId, onSuccess }: VehicleFormProps) {
  const { toast } = useToast();

  // Fetch customers for dropdown
  const { data: customers, isLoading: customersLoading } = useQuery<Customer[]>({
    queryKey: ['/api/customers'],
  });

  // Form initialization
  const form = useForm<z.infer<typeof vehicleFormSchema>>({
    resolver: zodResolver(vehicleFormSchema),
    defaultValues: {
      customerId: vehicle?.customerId || preSelectedCustomerId || 0,
      manufacturer: vehicle?.manufacturer || "",
      model: vehicle?.model || "",
      year: vehicle?.year || new Date().getFullYear(),
      licensePlate: vehicle?.licensePlate || "",
    },
  });

  // Create or update mutation
  const mutation = useMutation({
    mutationFn: async (values: z.infer<typeof vehicleFormSchema>) => {
      if (vehicle) {
        // Update existing vehicle
        const res = await apiRequest(
          "PUT",
          `/api/vehicles/${vehicle.id}`,
          values
        );
        return res.json();
      } else {
        // Create new vehicle
        const res = await apiRequest("POST", "/api/vehicles", values);
        return res.json();
      }
    },
    onSuccess: () => {
      toast({
        title: vehicle ? "Veículo atualizado" : "Veículo cadastrado",
        description: vehicle
          ? "Veículo atualizado com sucesso"
          : "Veículo cadastrado com sucesso",
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: `Não foi possível ${
          vehicle ? "atualizar" : "cadastrar"
        } o veículo: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Form submission handler
  const onSubmit = (values: z.infer<typeof vehicleFormSchema>) => {
    mutation.mutate(values);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="customerId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Cliente*</FormLabel>
              <Select 
                value={field.value ? field.value.toString() : ""} 
                onValueChange={value => field.onChange(parseInt(value))}
                disabled={customersLoading}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o cliente" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {customers && customers.map(customer => (
                    <SelectItem key={customer.id} value={customer.id.toString()}>
                      {customer.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="manufacturer"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Fabricante*</FormLabel>
                <Select 
                  value={field.value} 
                  onValueChange={field.onChange}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o fabricante" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {manufacturers.map(manufacturer => (
                      <SelectItem key={manufacturer} value={manufacturer}>
                        {manufacturer}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="model"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Modelo*</FormLabel>
                <FormControl>
                  <Input placeholder="Modelo do veículo" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="year"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Ano*</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    placeholder="Ano do veículo" 
                    min={1900}
                    max={new Date().getFullYear() + 1}
                    {...field}
                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="licensePlate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Placa*</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="ABC-1234" 
                    {...field} 
                    onChange={(e) => field.onChange(e.target.value.toUpperCase())}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex justify-end space-x-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={onSuccess}
            disabled={mutation.isPending}
          >
            Cancelar
          </Button>
          <Button type="submit" disabled={mutation.isPending}>
            {mutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Salvando...
              </>
            ) : (
              <>Salvar Veículo</>
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}
