import React, { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { UploadCloud, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type FileUploadProps = {
  onChange: (files: File[]) => void;
  maxFiles?: number;
  maxSizeInMB?: number;
  acceptedFileTypes?: string;
  initialFiles?: File[];
};

export function FileUpload({
  onChange,
  maxFiles = 5,
  maxSizeInMB = 5,
  acceptedFileTypes = "*",
  initialFiles = []
}: FileUploadProps) {
  const [files, setFiles] = useState<File[]>(initialFiles);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files || []);
    
    // Check file count
    if (selectedFiles.length + files.length > maxFiles) {
      toast({
        title: "Limite excedido",
        description: `Você pode enviar no máximo ${maxFiles} arquivos`,
        variant: "destructive"
      });
      return;
    }
    
    // Check file sizes
    const maxSizeInBytes = maxSizeInMB * 1024 * 1024;
    const oversizedFiles = selectedFiles.filter(file => file.size > maxSizeInBytes);
    
    if (oversizedFiles.length > 0) {
      toast({
        title: "Arquivo muito grande",
        description: `Um ou mais arquivos excedem o tamanho máximo de ${maxSizeInMB}MB`,
        variant: "destructive"
      });
      return;
    }
    
    // Update state and call onChange
    const newFiles = [...files, ...selectedFiles];
    setFiles(newFiles);
    onChange(newFiles);
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleRemoveFile = (index: number) => {
    const newFiles = [...files];
    newFiles.splice(index, 1);
    setFiles(newFiles);
    onChange(newFiles);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFiles = Array.from(e.dataTransfer.files);
      
      // Check file count
      if (droppedFiles.length + files.length > maxFiles) {
        toast({
          title: "Limite excedido",
          description: `Você pode enviar no máximo ${maxFiles} arquivos`,
          variant: "destructive"
        });
        return;
      }
      
      // Check file sizes
      const maxSizeInBytes = maxSizeInMB * 1024 * 1024;
      const oversizedFiles = droppedFiles.filter(file => file.size > maxSizeInBytes);
      
      if (oversizedFiles.length > 0) {
        toast({
          title: "Arquivo muito grande",
          description: `Um ou mais arquivos excedem o tamanho máximo de ${maxSizeInMB}MB`,
          variant: "destructive"
        });
        return;
      }
      
      // Update state and call onChange
      const newFiles = [...files, ...droppedFiles];
      setFiles(newFiles);
      onChange(newFiles);
    }
  };

  return (
    <div className="w-full">
      <div
        className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center cursor-pointer"
        onClick={() => fileInputRef.current?.click()}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        <UploadCloud className="h-12 w-12 text-gray-400 mx-auto mb-2" />
        <p className="text-gray-700 mb-1">Arraste fotos ou clique para selecionar</p>
        <p className="text-xs text-gray-500">
          Máximo {maxFiles} arquivos, formato {acceptedFileTypes.replace('*', 'qualquer').replace('image/*', 'imagem')}
          {maxSizeInMB && ` (max. ${maxSizeInMB}MB cada)`}
        </p>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept={acceptedFileTypes}
          multiple={maxFiles > 1}
          onChange={handleFileChange}
        />
      </div>

      {files.length > 0 && (
        <div className="mt-4 grid grid-cols-2 md:grid-cols-5 gap-2">
          {files.map((file, index) => (
            <div key={index} className="relative group">
              <div className="border rounded-md overflow-hidden h-24 bg-gray-50 flex items-center justify-center">
                {file.type.startsWith('image/') ? (
                  <img
                    src={URL.createObjectURL(file)}
                    alt={`Preview ${index + 1}`}
                    className="object-cover h-full w-full"
                  />
                ) : (
                  <div className="text-center p-2">
                    <div className="text-xs truncate max-w-full">{file.name}</div>
                    <div className="text-xs text-gray-500">{(file.size / 1024).toFixed(0)} KB</div>
                  </div>
                )}
              </div>
              <Button
                type="button"
                variant="destructive"
                size="icon"
                className="h-6 w-6 absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={(e) => {
                  e.stopPropagation();
                  handleRemoveFile(index);
                }}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
