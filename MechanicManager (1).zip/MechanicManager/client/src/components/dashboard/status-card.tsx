import { 
  Car, Users, FileText, Wrench, BarChart3, 
  ShoppingCart, TrendingUp, AlertCircle, Ban,
  Bell, Calendar, CreditCard, DollarSign
} from "lucide-react";

type StatusCardProps = {
  title: string;
  value: number | string;
  icon: string;
  color: string;
};

const getIcon = (name: string) => {
  switch (name) {
    case 'users':
      return <Users className="h-6 w-6" />;
    case 'car':
      return <Car className="h-6 w-6" />;
    case 'file':
      return <FileText className="h-6 w-6" />;
    case 'tools':
      return <Wrench className="h-6 w-6" />;
    case 'chart':
      return <BarChart3 className="h-6 w-6" />;
    case 'cart':
      return <ShoppingCart className="h-6 w-6" />;
    case 'trending':
      return <TrendingUp className="h-6 w-6" />;
    case 'alert':
      return <AlertCircle className="h-6 w-6" />;
    case 'ban':
      return <Ban className="h-6 w-6" />;
    case 'bell':
      return <Bell className="h-6 w-6" />;
    case 'calendar':
      return <Calendar className="h-6 w-6" />;
    case 'credit-card':
      return <CreditCard className="h-6 w-6" />;
    case 'dollar':
      return <DollarSign className="h-6 w-6" />;
    default:
      return <BarChart3 className="h-6 w-6" />;
  }
};

const getColorClass = (color: string) => {
  const colors = {
    primary: {
      bg: 'bg-primary/20',
      text: 'text-primary'
    },
    secondary: {
      bg: 'bg-orange-500/20',
      text: 'text-orange-500'
    },
    success: {
      bg: 'bg-green-500/20',
      text: 'text-green-500'
    },
    warning: {
      bg: 'bg-yellow-500/20',
      text: 'text-yellow-500'
    },
    error: {
      bg: 'bg-red-500/20',
      text: 'text-red-500'
    },
    info: {
      bg: 'bg-blue-500/20',
      text: 'text-blue-500'
    }
  };

  return colors[color as keyof typeof colors] || colors.primary;
};

export default function StatusCard({ title, value, icon, color }: StatusCardProps) {
  const colorClass = getColorClass(color);

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <div className="flex items-center">
        <div className={`p-3 rounded-full ${colorClass.bg} ${colorClass.text} mr-4`}>
          {getIcon(icon)}
        </div>
        <div>
          <p className="text-sm text-gray-600 font-medium">{title}</p>
          <p className="text-2xl font-semibold">{value}</p>
        </div>
      </div>
    </div>
  );
}
