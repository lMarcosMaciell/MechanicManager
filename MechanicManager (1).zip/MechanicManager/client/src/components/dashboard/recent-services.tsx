import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatDate } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { Customer, Vehicle } from "@shared/schema";

type RecentServicesProps = {
  services: any[];
};

export default function RecentServices({ services }: RecentServicesProps) {
  // Fetch customers for lookup
  const { data: customers } = useQuery<Customer[]>({
    queryKey: ['/api/customers'],
  });

  // Fetch vehicles for lookup
  const { data: vehicles } = useQuery<Vehicle[]>({
    queryKey: ['/api/vehicles'],
  });

  // Helper functions to get names
  const getCustomerName = (customerId: number) => {
    const customer = customers?.find(c => c.id === customerId);
    return customer?.name || 'Cliente não encontrado';
  };

  const getVehicleInfo = (vehicleId: number) => {
    const vehicle = vehicles?.find(v => v.id === vehicleId);
    if (!vehicle) return 'Veículo não encontrado';
    return `${vehicle.manufacturer} ${vehicle.model} (${vehicle.licensePlate})`;
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'in_progress':
        return 'bg-green-100 text-green-800';
      case 'waiting_parts':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      case 'paused':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'in_progress':
        return 'Em Andamento';
      case 'waiting_parts':
        return 'Aguardando Peças';
      case 'completed':
        return 'Finalizado';
      case 'paused':
        return 'Pausado';
      default:
        return 'Desconhecido';
    }
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium">Serviços Recentes</CardTitle>
      </CardHeader>
      <CardContent>
        {services.length === 0 ? (
          <p className="text-sm text-gray-500 py-4 text-center">
            Nenhum serviço em andamento
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="text-left text-sm text-gray-500">
                  <th className="pb-2 font-medium">Cliente</th>
                  <th className="pb-2 font-medium">Veículo</th>
                  <th className="pb-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {services.map((service) => (
                  <tr key={service.id} className="border-t border-gray-200">
                    <td className="py-2">{getCustomerName(service.customerId)}</td>
                    <td className="py-2">{getVehicleInfo(service.vehicleId)}</td>
                    <td className="py-2">
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusBadgeClass(service.status)}`}>
                        {getStatusText(service.status)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
