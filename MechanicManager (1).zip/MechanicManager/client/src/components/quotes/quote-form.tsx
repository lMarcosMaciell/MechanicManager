import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Quote, insertQuoteSchema, Customer, Vehicle, QuoteItem } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { formatCurrency } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { generateId } from "@/lib/utils";

// Quote form schema with validation
const quoteFormSchema = insertQuoteSchema.extend({
  customerId: z.number({
    required_error: "Por favor selecione um cliente",
    invalid_type_error: "Por favor selecione um cliente válido"
  }),
  vehicleId: z.number({
    required_error: "Por favor selecione um veículo",
    invalid_type_error: "Por favor selecione um veículo válido"
  }),
  items: z.any(), // This will be managed separately
  date: z.string(),
  validUntil: z.string(),
  status: z.string().default("pending"),
  notes: z.string().optional(),
  total: z.number().min(0, "O total não pode ser negativo"), // Garantir que o total seja um número
});

// Quote item schema
const quoteItemSchema = z.object({
  id: z.string(),
  description: z.string().min(1, "A descrição é obrigatória"),
  quantity: z.number().min(1, "A quantidade deve ser maior que zero"),
  price: z.number().min(0, "O preço não pode ser negativo"),
  type: z.enum(["service", "part"])
});

type QuoteFormProps = {
  quote?: Quote | null;
  preSelectedCustomerId?: number | null;
  preSelectedVehicleId?: number | null;
  readOnly?: boolean;
  onSuccess: () => void;
};

export default function QuoteForm({ 
  quote, 
  preSelectedCustomerId, 
  preSelectedVehicleId, 
  readOnly = false, 
  onSuccess 
}: QuoteFormProps) {
  const { toast } = useToast();
  const [serviceItems, setServiceItems] = useState<QuoteItem[]>([]);
  const [partItems, setPartItems] = useState<QuoteItem[]>([]);
  const [servicesTotal, setServicesTotal] = useState(0);
  const [partsTotal, setPartsTotal] = useState(0);
  const [totalPrice, setTotalPrice] = useState(0);
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | undefined>(
    quote?.customerId || preSelectedCustomerId || undefined
  );

  // Fetch customers for dropdown
  const { data: customers } = useQuery<Customer[]>({
    queryKey: ['/api/customers'],
  });

  // Fetch vehicles for dropdown
  const { data: vehicles } = useQuery<Vehicle[]>({
    queryKey: ['/api/vehicles'],
  });
  
  // Filter vehicles by selected customer
  const customerVehicles = vehicles?.filter(vehicle => 
    vehicle.customerId === selectedCustomerId
  ) || [];

  // Initialize form
  const form = useForm<z.infer<typeof quoteFormSchema>>({
    resolver: zodResolver(quoteFormSchema),
    defaultValues: {
      customerId: quote?.customerId || preSelectedCustomerId || 0,
      vehicleId: quote?.vehicleId || preSelectedVehicleId || 0,
      date: quote?.date 
        ? new Date(quote.date).toISOString().split('T')[0] 
        : new Date().toISOString().split('T')[0],
      validUntil: quote?.validUntil 
        ? new Date(quote.validUntil).toISOString().split('T')[0] 
        : new Date(new Date().setDate(new Date().getDate() + 15)).toISOString().split('T')[0],
      status: quote?.status || "pending",
      notes: quote?.notes || "",
      total: quote?.total ? Number(quote.total) : 0,
    },
  });

  // Initialize items from quote if editing
  useEffect(() => {
    if (quote?.items) {
      try {
        const items = Array.isArray(quote.items) ? quote.items : JSON.parse(String(quote.items));
        const serviceItems = items.filter((item: QuoteItem) => item.type === 'service')
          .map((item: QuoteItem) => ({ ...item, id: generateId() }));
        const partItems = items.filter((item: QuoteItem) => item.type === 'part')
          .map((item: QuoteItem) => ({ ...item, id: generateId() }));
        
        setServiceItems(serviceItems);
        setPartItems(partItems);
      } catch (error) {
        console.error("Error parsing quote items:", error);
      }
    } else {
      // Add default items if creating new quote
      if (!readOnly) {
        setServiceItems([{ id: generateId(), description: '', quantity: 1, price: 0, type: 'service' }]);
        setPartItems([{ id: generateId(), description: '', quantity: 1, price: 0, type: 'part' }]);
      }
    }
  }, [quote]);

  // Calculate totals when items change
  useEffect(() => {
    const sTotal = serviceItems.reduce((acc, item) => acc + (item.quantity * item.price), 0);
    const pTotal = partItems.reduce((acc, item) => acc + (item.quantity * item.price), 0);
    setServicesTotal(sTotal);
    setPartsTotal(pTotal);
    setTotalPrice(sTotal + pTotal);
    
    // Atualiza o campo total no formulário
    form.setValue('total', sTotal + pTotal);
  }, [serviceItems, partItems, form]);

  // Add service item
  const addServiceItem = () => {
    setServiceItems([
      ...serviceItems, 
      { id: generateId(), description: '', quantity: 1, price: 0, type: 'service' }
    ]);
  };

  // Add part item
  const addPartItem = () => {
    setPartItems([
      ...partItems, 
      { id: generateId(), description: '', quantity: 1, price: 0, type: 'part' }
    ]);
  };

  // Remove service item
  const removeServiceItem = (id: string) => {
    if (serviceItems.length > 1) {
      setServiceItems(serviceItems.filter(item => item.id !== id));
    }
  };

  // Remove part item
  const removePartItem = (id: string) => {
    if (partItems.length > 1) {
      setPartItems(partItems.filter(item => item.id !== id));
    }
  };

  // Update service item
  const updateServiceItem = (id: string, field: keyof QuoteItem, value: any) => {
    setServiceItems(serviceItems.map(item => 
      item.id === id ? { ...item, [field]: field === 'quantity' || field === 'price' ? Number(value) : value } : item
    ));
  };

  // Update part item
  const updatePartItem = (id: string, field: keyof QuoteItem, value: any) => {
    setPartItems(partItems.map(item => 
      item.id === id ? { ...item, [field]: field === 'quantity' || field === 'price' ? Number(value) : value } : item
    ));
  };

  // Create or update mutation
  const mutation = useMutation({
    mutationFn: async (values: z.infer<typeof quoteFormSchema>) => {
      // Combine service and part items
      const allItems = [...serviceItems, ...partItems];
      
      // Validate items
      for (const item of allItems) {
        try {
          quoteItemSchema.parse(item);
        } catch (error) {
          throw new Error(`Item inválido: ${(error as any).message}`);
        }
      }
      
      // Converta quaisquer números em string para valores numéricos
      const quoteData = {
        customerId: Number(values.customerId),
        vehicleId: Number(values.vehicleId),
        date: values.date,
        validUntil: values.validUntil,
        status: values.status,
        notes: values.notes || "",
        total: Number(totalPrice),
        items: allItems
      };
      
      console.log("Enviando para o servidor:", quoteData);
      
      if (quote) {
        // Update existing quote
        const res = await apiRequest(
          "PUT",
          `/api/quotes/${quote.id}`,
          quoteData
        );
        return res.json();
      } else {
        // Create new quote
        const res = await apiRequest("POST", "/api/quotes", quoteData);
        return res.json();
      }
    },
    onSuccess: () => {
      toast({
        title: quote ? "Orçamento atualizado" : "Orçamento criado",
        description: quote
          ? "Orçamento atualizado com sucesso"
          : "Orçamento criado com sucesso",
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: `Não foi possível ${
          quote ? "atualizar" : "criar"
        } o orçamento: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Form submission handler
  const onSubmit = (values: z.infer<typeof quoteFormSchema>) => {
    // Garantir que o total seja enviado como string para o backend
    const formattedValues = {
      ...values,
      total: values.total.toString(),
      // Garantir que os items estejam como array para enviar ao backend
      items: [...serviceItems, ...partItems]
    };
    
    console.log("Enviando para o servidor:", formattedValues);
    mutation.mutate(formattedValues);
  };

  if (readOnly) {
    // Read-only quote view
    const customer = customers?.find(c => c.id === quote?.customerId);
    const vehicle = vehicles?.find(v => v.id === quote?.vehicleId);
    
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h3 className="text-sm font-medium text-gray-500">Cliente</h3>
            <p className="text-lg">{customer?.name || "Cliente não encontrado"}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Veículo</h3>
            <p className="text-lg">
              {vehicle 
                ? `${vehicle.manufacturer} ${vehicle.model} (${vehicle.licensePlate})` 
                : "Veículo não encontrado"}
            </p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Data</h3>
            <p className="text-lg">{quote?.date ? new Date(quote.date).toLocaleDateString('pt-BR') : ""}</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Validade</h3>
            <p className="text-lg">{quote?.validUntil ? new Date(quote.validUntil).toLocaleDateString('pt-BR') : ""}</p>
          </div>
        </div>
        
        <div>
          <h3 className="text-sm font-medium text-gray-500 mb-2">Serviços</h3>
          {serviceItems.length > 0 ? (
            <div className="border rounded-md">
              <table className="min-w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="py-2 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Descrição</th>
                    <th className="py-2 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantidade</th>
                    <th className="py-2 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Valor Unit.</th>
                    <th className="py-2 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {serviceItems.map((item) => (
                    <tr key={item.id}>
                      <td className="py-2 px-4 text-sm">{item.description}</td>
                      <td className="py-2 px-4 text-sm">{item.quantity}</td>
                      <td className="py-2 px-4 text-sm">{formatCurrency(item.price)}</td>
                      <td className="py-2 px-4 text-sm font-medium">{formatCurrency(item.quantity * item.price)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-sm text-gray-500 italic">Nenhum serviço adicionado</p>
          )}
        </div>
        
        <div>
          <h3 className="text-sm font-medium text-gray-500 mb-2">Peças</h3>
          {partItems.length > 0 ? (
            <div className="border rounded-md">
              <table className="min-w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="py-2 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Descrição</th>
                    <th className="py-2 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantidade</th>
                    <th className="py-2 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Valor Unit.</th>
                    <th className="py-2 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {partItems.map((item) => (
                    <tr key={item.id}>
                      <td className="py-2 px-4 text-sm">{item.description}</td>
                      <td className="py-2 px-4 text-sm">{item.quantity}</td>
                      <td className="py-2 px-4 text-sm">{formatCurrency(item.price)}</td>
                      <td className="py-2 px-4 text-sm font-medium">{formatCurrency(item.quantity * item.price)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-sm text-gray-500 italic">Nenhuma peça adicionada</p>
          )}
        </div>
        
        {quote?.notes && (
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-1">Observações</h3>
            <p className="text-sm">{quote.notes}</p>
          </div>
        )}
        
        <Separator />
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <p className="text-sm text-gray-600">Total Serviços: <span className="font-medium">{formatCurrency(servicesTotal)}</span></p>
            <p className="text-sm text-gray-600">Total Peças: <span className="font-medium">{formatCurrency(partsTotal)}</span></p>
            <p className="text-lg font-medium mt-1">Total Geral: <span className="text-primary font-bold">{formatCurrency(totalPrice)}</span></p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <Button type="button" onClick={onSuccess}>
              Fechar
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="customerId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Cliente*</FormLabel>
                <Select 
                  value={field.value ? field.value.toString() : ""} 
                  onValueChange={(value) => {
                    const customerId = parseInt(value);
                    field.onChange(customerId);
                    setSelectedCustomerId(customerId);
                    // Reset vehicle if customer changes
                    form.setValue('vehicleId', 0);
                  }}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o cliente" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {customers && customers.map(customer => (
                      <SelectItem key={customer.id} value={customer.id.toString()}>
                        {customer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="vehicleId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Veículo*</FormLabel>
                <Select 
                  value={field.value ? field.value.toString() : ""} 
                  onValueChange={value => field.onChange(parseInt(value))}
                  disabled={!selectedCustomerId || customerVehicles.length === 0}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder={
                        !selectedCustomerId 
                          ? "Selecione um cliente primeiro" 
                          : customerVehicles.length === 0 
                            ? "Nenhum veículo disponível" 
                            : "Selecione o veículo"
                      } />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {customerVehicles.map(vehicle => (
                      <SelectItem key={vehicle.id} value={vehicle.id.toString()}>
                        {`${vehicle.manufacturer} ${vehicle.model} (${vehicle.licensePlate})`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="date"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Data*</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="validUntil"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Validade*</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">Serviços a Realizar</h3>
          <Card>
            <CardContent className="p-4">
              {serviceItems.map((item, index) => (
                <div key={item.id} className="grid grid-cols-12 gap-2 mb-3">
                  <div className="col-span-6">
                    <label className="block text-xs font-medium text-gray-700 mb-1">Descrição do Serviço*</label>
                    <Input 
                      value={item.description}
                      onChange={(e) => updateServiceItem(item.id, 'description', e.target.value)}
                      placeholder="Descrição do serviço"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs font-medium text-gray-700 mb-1">Quantidade*</label>
                    <Input 
                      type="number"
                      min="1"
                      value={item.quantity}
                      onChange={(e) => updateServiceItem(item.id, 'quantity', e.target.value)}
                    />
                  </div>
                  <div className="col-span-3">
                    <label className="block text-xs font-medium text-gray-700 mb-1">Valor Unitário*</label>
                    <Input 
                      type="number"
                      min="0"
                      step="0.01"
                      value={item.price}
                      onChange={(e) => updateServiceItem(item.id, 'price', e.target.value)}
                      placeholder="0.00"
                    />
                  </div>
                  <div className="col-span-1 flex items-end">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      type="button"
                      onClick={() => removeServiceItem(item.id)}
                      disabled={serviceItems.length <= 1}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              
              <Button 
                variant="outline" 
                type="button" 
                onClick={addServiceItem}
                className="mt-2"
              >
                <Plus className="h-4 w-4 mr-2" />
                Adicionar Serviço
              </Button>
            </CardContent>
          </Card>
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">Peças Necessárias</h3>
          <Card>
            <CardContent className="p-4">
              {partItems.map((item, index) => (
                <div key={item.id} className="grid grid-cols-12 gap-2 mb-3">
                  <div className="col-span-6">
                    <label className="block text-xs font-medium text-gray-700 mb-1">Descrição da Peça*</label>
                    <Input 
                      value={item.description}
                      onChange={(e) => updatePartItem(item.id, 'description', e.target.value)}
                      placeholder="Descrição da peça"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs font-medium text-gray-700 mb-1">Quantidade*</label>
                    <Input 
                      type="number"
                      min="1"
                      value={item.quantity}
                      onChange={(e) => updatePartItem(item.id, 'quantity', e.target.value)}
                    />
                  </div>
                  <div className="col-span-3">
                    <label className="block text-xs font-medium text-gray-700 mb-1">Valor Unitário*</label>
                    <Input 
                      type="number"
                      min="0"
                      step="0.01"
                      value={item.price}
                      onChange={(e) => updatePartItem(item.id, 'price', e.target.value)}
                      placeholder="0.00"
                    />
                  </div>
                  <div className="col-span-1 flex items-end">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      type="button"
                      onClick={() => removePartItem(item.id)}
                      disabled={partItems.length <= 1}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              
              <Button 
                variant="outline" 
                type="button" 
                onClick={addPartItem}
                className="mt-2"
              >
                <Plus className="h-4 w-4 mr-2" />
                Adicionar Peça
              </Button>
            </CardContent>
          </Card>
        </div>

        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Observações</FormLabel>
              <FormControl>
                <Textarea placeholder="Observações adicionais" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Separator />

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <p className="text-sm text-gray-600">Total Serviços: <span className="font-medium">{formatCurrency(servicesTotal)}</span></p>
            <p className="text-sm text-gray-600">Total Peças: <span className="font-medium">{formatCurrency(partsTotal)}</span></p>
            <p className="text-lg font-medium mt-1">Total Geral: <span className="text-primary font-bold">{formatCurrency(totalPrice)}</span></p>
          </div>
          
          <div className="flex space-x-2 mt-4 md:mt-0">
            <Button
              type="button"
              variant="outline"
              onClick={onSuccess}
              disabled={mutation.isPending}
            >
              Cancelar
            </Button>
            <Button type="submit" disabled={mutation.isPending}>
              {mutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>Gerar Orçamento</>
              )}
            </Button>
          </div>
        </div>
      </form>
    </Form>
  );
}
