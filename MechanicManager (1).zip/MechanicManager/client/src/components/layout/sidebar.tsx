import { useLocation, Link } from "wouter";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { LayoutDashboard, Users, Car, FileText, Wrench } from "lucide-react";

type NavItem = {
  title: string;
  href: string;
  icon: React.ReactNode;
};

const navItems: NavItem[] = [
  {
    title: "Dashboard",
    href: "/",
    icon: <LayoutDashboard className="mr-3 h-5 w-5" />,
  },
  {
    title: "Clientes",
    href: "/customers",
    icon: <Users className="mr-3 h-5 w-5" />,
  },
  {
    title: "Veículos",
    href: "/vehicles",
    icon: <Car className="mr-3 h-5 w-5" />,
  },
  {
    title: "Orçamentos",
    href: "/quotes",
    icon: <FileText className="mr-3 h-5 w-5" />,
  },
  {
    title: "Serviços em Andamento",
    href: "/services",
    icon: <Wrench className="mr-3 h-5 w-5" />,
  },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="bg-white w-64 border-r border-gray-200 hidden md:block transition-all duration-300 ease-in-out">
      <ScrollArea className="h-full">
        <nav className="p-4">
          <ul className="space-y-2">
            {navItems.map((item) => (
              <li key={item.href}>
                <Link href={item.href}>
                  <a
                    className={cn(
                      "flex items-center px-3 py-2 rounded-md text-gray-700 hover:bg-gray-100 hover:text-primary transition duration-200",
                      location === item.href && "bg-gray-100 text-primary font-medium"
                    )}
                  >
                    {item.icon}
                    <span>{item.title}</span>
                  </a>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </ScrollArea>
    </aside>
  );
}
