import React from "react";
import { Document, Page, Text, View, StyleSheet, Image, Font } from "@react-pdf/renderer";
import { Quote, Customer, Vehicle, QuoteItem } from "@shared/schema";
import { formatCurrency, formatDate, formatPhoneNumber } from "@/lib/utils";

// Register fonts
Font.register({
  family: "Roboto",
  fonts: [
    { src: "https://cdnjs.cloudflare.com/ajax/libs/ink/3.1.10/fonts/Roboto/roboto-regular-webfont.ttf", fontWeight: 400 },
    { src: "https://cdnjs.cloudflare.com/ajax/libs/ink/3.1.10/fonts/Roboto/roboto-medium-webfont.ttf", fontWeight: 500 },
    { src: "https://cdnjs.cloudflare.com/ajax/libs/ink/3.1.10/fonts/Roboto/roboto-bold-webfont.ttf", fontWeight: 700 },
  ],
});

// Create styles
const styles = StyleSheet.create({
  page: {
    padding: 30,
    fontSize: 12,
    fontFamily: "Roboto",
    backgroundColor: "#fff",
  },
  header: {
    marginBottom: 20,
    borderBottom: "1 solid #dee2e6",
    paddingBottom: 10,
  },
  headerContent: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  logo: {
    width: 150,
    marginBottom: 10,
  },
  title: {
    fontSize: 18,
    fontWeight: 700,
    color: "#1976d2",
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: "#6c757d",
  },
  infoBox: {
    marginBottom: 15,
  },
  infoTitle: {
    fontSize: 12,
    fontWeight: 700,
    marginBottom: 5,
    color: "#495057",
  },
  infoRow: {
    flexDirection: "row",
    marginBottom: 3,
  },
  infoLabel: {
    width: 80,
    fontWeight: 500,
  },
  infoValue: {
    flex: 1,
  },
  section: {
    marginTop: 15,
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: 700,
    marginBottom: 8,
    color: "#1976d2",
    borderBottom: "1 solid #dee2e6",
    paddingBottom: 3,
  },
  table: {
    display: "table",
    width: "100%",
    borderStyle: "solid",
    borderWidth: 1,
    borderColor: "#dee2e6",
    marginBottom: 15,
  },
  tableRow: {
    flexDirection: "row",
    borderBottomWidth: 1,
    borderBottomColor: "#dee2e6",
    borderBottomStyle: "solid",
  },
  tableRowHeader: {
    backgroundColor: "#f8f9fa",
  },
  tableRowEven: {
    backgroundColor: "#ffffff",
  },
  tableRowOdd: {
    backgroundColor: "#f9fafb",
  },
  tableCol: {
    padding: 5,
  },
  tableColDescription: {
    width: "50%",
  },
  tableColQuantity: {
    width: "15%",
    textAlign: "center",
  },
  tableColPrice: {
    width: "17.5%",
    textAlign: "right",
  },
  tableColTotal: {
    width: "17.5%",
    textAlign: "right",
  },
  tableHeader: {
    fontWeight: 700,
    fontSize: 10,
    color: "#495057",
  },
  totalSection: {
    marginTop: 10,
    alignItems: "flex-end",
  },
  totalRow: {
    flexDirection: "row",
    marginTop: 2,
  },
  totalLabel: {
    width: 120,
    textAlign: "right",
    marginRight: 10,
    fontWeight: 500,
  },
  totalValue: {
    width: 100,
    textAlign: "right",
  },
  grandTotal: {
    fontWeight: 700,
    fontSize: 14,
    color: "#1976d2",
  },
  notes: {
    marginTop: 20,
    padding: 10,
    backgroundColor: "#f8f9fa",
    borderRadius: 4,
  },
  notesTitle: {
    fontWeight: 700,
    marginBottom: 5,
  },
  footer: {
    position: "absolute",
    bottom: 30,
    left: 30,
    right: 30,
    borderTopWidth: 1,
    borderTopColor: "#dee2e6",
    borderTopStyle: "solid",
    paddingTop: 10,
    fontSize: 10,
    color: "#6c757d",
    textAlign: "center",
  },
  signatureSection: {
    marginTop: 40,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  signatureBox: {
    width: "45%",
  },
  signatureLine: {
    borderTopWidth: 1,
    borderTopColor: "#000",
    borderTopStyle: "solid",
    marginTop: 40,
    paddingTop: 5,
    textAlign: "center",
  },
});

interface QuotePDFProps {
  quote: Quote;
  customer: Customer;
  vehicle: Vehicle;
}

const QuotePDF: React.FC<QuotePDFProps> = ({ quote, customer, vehicle }) => {
  // Separate items by type
  const serviceItems = Array.isArray(quote.items) 
    ? quote.items.filter((item: QuoteItem) => item.type === 'service')
    : [];
    
  const partItems = Array.isArray(quote.items) 
    ? quote.items.filter((item: QuoteItem) => item.type === 'part')
    : [];
  
  // Calculate totals
  const servicesTotal = serviceItems.reduce((acc, item) => acc + (item.quantity * item.price), 0);
  const partsTotal = partItems.reduce((acc, item) => acc + (item.quantity * item.price), 0);
  const totalValue = servicesTotal + partsTotal;

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerContent}>
            <View>
              <Text style={styles.title}>AUTOGEST OFICINA</Text>
              <Text style={styles.subtitle}>Sistema de Gestão para Oficinas</Text>
            </View>
            <View>
              <Text style={{ fontSize: 16, fontWeight: 700 }}>ORÇAMENTO #{quote.id.toString().padStart(3, '0')}</Text>
              <Text>Data: {formatDate(quote.date)}</Text>
              <Text>Validade: {formatDate(quote.validUntil)}</Text>
            </View>
          </View>
        </View>
        
        {/* Customer and Vehicle Information */}
        <View style={{ flexDirection: "row" }}>
          <View style={[styles.infoBox, { flex: 1, marginRight: 10 }]}>
            <Text style={styles.infoTitle}>INFORMAÇÕES DO CLIENTE</Text>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Nome:</Text>
              <Text style={styles.infoValue}>{customer.name}</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Telefone:</Text>
              <Text style={styles.infoValue}>{formatPhoneNumber(customer.phone)}</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Endereço:</Text>
              <Text style={styles.infoValue}>{customer.address}</Text>
            </View>
          </View>
          
          <View style={[styles.infoBox, { flex: 1 }]}>
            <Text style={styles.infoTitle}>INFORMAÇÕES DO VEÍCULO</Text>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Fabricante:</Text>
              <Text style={styles.infoValue}>{vehicle.manufacturer}</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Modelo:</Text>
              <Text style={styles.infoValue}>{vehicle.model}</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Ano:</Text>
              <Text style={styles.infoValue}>{vehicle.year}</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Placa:</Text>
              <Text style={styles.infoValue}>{vehicle.licensePlate}</Text>
            </View>
          </View>
        </View>
        
        {/* Services Table */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>SERVIÇOS</Text>
          
          {serviceItems.length > 0 ? (
            <View style={styles.table}>
              {/* Table Header */}
              <View style={[styles.tableRow, styles.tableRowHeader]}>
                <View style={[styles.tableCol, styles.tableColDescription]}>
                  <Text style={styles.tableHeader}>Descrição</Text>
                </View>
                <View style={[styles.tableCol, styles.tableColQuantity]}>
                  <Text style={styles.tableHeader}>Quantidade</Text>
                </View>
                <View style={[styles.tableCol, styles.tableColPrice]}>
                  <Text style={styles.tableHeader}>Valor Unit.</Text>
                </View>
                <View style={[styles.tableCol, styles.tableColTotal]}>
                  <Text style={styles.tableHeader}>Total</Text>
                </View>
              </View>
              
              {/* Table Rows */}
              {serviceItems.map((item, index) => (
                <View 
                  key={`service-${index}`} 
                  style={[
                    styles.tableRow, 
                    index % 2 === 0 ? styles.tableRowEven : styles.tableRowOdd
                  ]}
                >
                  <View style={[styles.tableCol, styles.tableColDescription]}>
                    <Text>{item.description}</Text>
                  </View>
                  <View style={[styles.tableCol, styles.tableColQuantity]}>
                    <Text>{item.quantity}</Text>
                  </View>
                  <View style={[styles.tableCol, styles.tableColPrice]}>
                    <Text>{formatCurrency(item.price)}</Text>
                  </View>
                  <View style={[styles.tableCol, styles.tableColTotal]}>
                    <Text>{formatCurrency(item.quantity * item.price)}</Text>
                  </View>
                </View>
              ))}
            </View>
          ) : (
            <Text>Nenhum serviço adicionado</Text>
          )}
        </View>
        
        {/* Parts Table */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>PEÇAS</Text>
          
          {partItems.length > 0 ? (
            <View style={styles.table}>
              {/* Table Header */}
              <View style={[styles.tableRow, styles.tableRowHeader]}>
                <View style={[styles.tableCol, styles.tableColDescription]}>
                  <Text style={styles.tableHeader}>Descrição</Text>
                </View>
                <View style={[styles.tableCol, styles.tableColQuantity]}>
                  <Text style={styles.tableHeader}>Quantidade</Text>
                </View>
                <View style={[styles.tableCol, styles.tableColPrice]}>
                  <Text style={styles.tableHeader}>Valor Unit.</Text>
                </View>
                <View style={[styles.tableCol, styles.tableColTotal]}>
                  <Text style={styles.tableHeader}>Total</Text>
                </View>
              </View>
              
              {/* Table Rows */}
              {partItems.map((item, index) => (
                <View 
                  key={`part-${index}`} 
                  style={[
                    styles.tableRow, 
                    index % 2 === 0 ? styles.tableRowEven : styles.tableRowOdd
                  ]}
                >
                  <View style={[styles.tableCol, styles.tableColDescription]}>
                    <Text>{item.description}</Text>
                  </View>
                  <View style={[styles.tableCol, styles.tableColQuantity]}>
                    <Text>{item.quantity}</Text>
                  </View>
                  <View style={[styles.tableCol, styles.tableColPrice]}>
                    <Text>{formatCurrency(item.price)}</Text>
                  </View>
                  <View style={[styles.tableCol, styles.tableColTotal]}>
                    <Text>{formatCurrency(item.quantity * item.price)}</Text>
                  </View>
                </View>
              ))}
            </View>
          ) : (
            <Text>Nenhuma peça adicionada</Text>
          )}
        </View>
        
        {/* Total Section */}
        <View style={styles.totalSection}>
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Subtotal Serviços:</Text>
            <Text style={styles.totalValue}>{formatCurrency(servicesTotal)}</Text>
          </View>
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Subtotal Peças:</Text>
            <Text style={styles.totalValue}>{formatCurrency(partsTotal)}</Text>
          </View>
          <View style={[styles.totalRow, { marginTop: 5 }]}>
            <Text style={[styles.totalLabel, styles.grandTotal]}>TOTAL:</Text>
            <Text style={[styles.totalValue, styles.grandTotal]}>{formatCurrency(totalValue)}</Text>
          </View>
        </View>
        
        {/* Notes */}
        {quote.notes && (
          <View style={styles.notes}>
            <Text style={styles.notesTitle}>Observações:</Text>
            <Text>{quote.notes}</Text>
          </View>
        )}
        
        {/* Signature */}
        <View style={styles.signatureSection}>
          <View style={styles.signatureBox}>
            <Text style={styles.signatureLine}>Assinatura do Cliente</Text>
          </View>
          <View style={styles.signatureBox}>
            <Text style={styles.signatureLine}>Assinatura da Oficina</Text>
          </View>
        </View>
        
        {/* Footer */}
        <View style={styles.footer}>
          <Text>AutoGest Oficina - Sistema de Gestão para Oficinas</Text>
          <Text>Orçamento gerado em {new Date().toLocaleDateString()} às {new Date().toLocaleTimeString()}</Text>
        </View>
      </Page>
    </Document>
  );
};

export default QuotePDF;
