import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import QuoteForm from "@/components/quotes/quote-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate, formatCurrency } from "@/lib/utils";
import { Quote, Customer, Vehicle } from "@shared/schema";
import { Plus, Search, Eye, CheckCircle, XCircle, Printer, Wrench } from "lucide-react";
import QuotePDF from "@/components/pdf/quote-pdf";
import { PDFDownloadLink } from "@react-pdf/renderer";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

export default function QuotesPage() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [viewingQuote, setViewingQuote] = useState<Quote | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  
  // Pegando parâmetros da URL para criar novo orçamento a partir de veículo
  const searchParams = new URLSearchParams(window.location.search);
  const preSelectedVehicleId = searchParams.get('vehicleId') ? parseInt(searchParams.get('vehicleId')!) : null;
  const preSelectedCustomerId = searchParams.get('customerId') ? parseInt(searchParams.get('customerId')!) : null;
  
  // Abrir automaticamente formulário se tiver parâmetros na URL
  useEffect(() => {
    if (window.location.pathname === '/quotes/new' && (preSelectedVehicleId || preSelectedCustomerId)) {
      setIsDialogOpen(true);
    }
  }, [preSelectedVehicleId, preSelectedCustomerId]);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedVehicleId, setSelectedVehicleId] = useState<number | null>(null);
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | null>(null);
  const itemsPerPage = 10;
  const { toast } = useToast();

  // Extract parameters from URL if available
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const vehicleId = params.get('vehicleId');
    const customerId = params.get('customerId');
    
    if (vehicleId) setSelectedVehicleId(parseInt(vehicleId));
    if (customerId) setSelectedCustomerId(parseInt(customerId));
    
    // If we have both, open the quote form automatically
    if (vehicleId && customerId) {
      setIsDialogOpen(true);
    }
  }, []);

  // Fetch quotes
  const { data: quotes, isLoading: quotesLoading } = useQuery<Quote[]>({
    queryKey: ['/api/quotes'],
  });

  // Fetch customers for lookup
  const { data: customers } = useQuery<Customer[]>({
    queryKey: ['/api/customers'],
  });

  // Fetch vehicles for lookup
  const { data: vehicles } = useQuery<Vehicle[]>({
    queryKey: ['/api/vehicles'],
  });

  // Update quote status mutation
  const updateQuoteStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number, status: string }) => {
      await apiRequest("PATCH", `/api/quotes/${id}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
      toast({
        title: "Status atualizado",
        description: "Status do orçamento atualizado com sucesso",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o status do orçamento",
        variant: "destructive",
      });
    }
  });

  // Handle status update
  const handleUpdateStatus = (id: number, status: string) => {
    let confirmMessage = '';
    if (status === 'approved') {
      confirmMessage = "Aprovar este orçamento?";
    } else if (status === 'rejected') {
      confirmMessage = "Rejeitar este orçamento?";
    }
    
    if (confirmMessage && window.confirm(confirmMessage)) {
      updateQuoteStatusMutation.mutate({ id, status });
    }
  };

  // Filter quotes
  const filteredQuotes = quotes 
    ? quotes.filter(quote => {
        // Match search term against customer or vehicle
        const customerMatch = customers?.find(c => c.id === quote.customerId)?.name.toLowerCase().includes(searchTerm.toLowerCase());
        const vehicle = vehicles?.find(v => v.id === quote.vehicleId);
        const vehicleMatch = vehicle ? 
          `${vehicle.manufacturer} ${vehicle.model}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
          vehicle.licensePlate.toLowerCase().includes(searchTerm.toLowerCase()) : false;
        
        // Apply filters
        return (searchTerm === "" || customerMatch || vehicleMatch) &&
               (statusFilter === "" || quote.status === statusFilter);
      })
    : [];

  // Paginate quotes
  const paginatedQuotes = filteredQuotes.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  
  const totalPages = Math.ceil(filteredQuotes.length / itemsPerPage);

  // Helper functions
  const getCustomerName = (customerId: number) => {
    const customer = customers?.find(c => c.id === customerId);
    return customer ? customer.name : 'Cliente não encontrado';
  };

  const getVehicleInfo = (vehicleId: number) => {
    const vehicle = vehicles?.find(v => v.id === vehicleId);
    return vehicle ? `${vehicle.manufacturer} ${vehicle.model} (${vehicle.licensePlate})` : 'Veículo não encontrado';
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Pendente';
      case 'approved':
        return 'Aprovado';
      case 'rejected':
        return 'Rejeitado';
      default:
        return 'Desconhecido';
    }
  };

  return (
    <div className="h-screen flex flex-col">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-auto bg-gray-50 p-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Orçamentos</h2>
              <p className="text-gray-600">Gerenciamento de orçamentos</p>
            </div>
            
            <Button onClick={() => {
              setViewingQuote(null);
              setIsDialogOpen(true);
            }}>
              <Plus className="mr-2 h-4 w-4" />
              Novo Orçamento
            </Button>
          </div>

          <div className="bg-white rounded-lg shadow">
            <div className="p-4 border-b border-gray-200">
              <div className="flex flex-col sm:flex-row justify-between gap-4">
                <div className="relative flex-grow">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input 
                    placeholder="Buscar orçamentos..." 
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <div className="flex gap-2">
                  <Select 
                    value={statusFilter} 
                    onValueChange={setStatusFilter}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Todos os Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os Status</SelectItem>
                      <SelectItem value="pending">Pendente</SelectItem>
                      <SelectItem value="approved">Aprovado</SelectItem>
                      <SelectItem value="rejected">Rejeitado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Nº</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Data</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Cliente</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Veículo</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Valor Total</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Status</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {quotesLoading ? (
                    <tr>
                      <td colSpan={7} className="text-center py-4">
                        <div className="flex justify-center">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                        </div>
                      </td>
                    </tr>
                  ) : paginatedQuotes.length > 0 ? (
                    paginatedQuotes.map((quote) => (
                      <tr key={quote.id} className="border-t border-gray-200">
                        <td className="py-3 px-4 text-sm">{quote.id.toString().padStart(3, '0')}</td>
                        <td className="py-3 px-4 text-sm">{formatDate(quote.date)}</td>
                        <td className="py-3 px-4 text-sm">{getCustomerName(quote.customerId)}</td>
                        <td className="py-3 px-4 text-sm">{getVehicleInfo(quote.vehicleId)}</td>
                        <td className="py-3 px-4 text-sm font-medium">{formatCurrency(quote.total)}</td>
                        <td className="py-3 px-4 text-sm">
                          <span className={`px-2 py-1 rounded-full text-xs ${getStatusBadgeClass(quote.status)}`}>
                            {getStatusText(quote.status)}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-sm">
                          <div className="flex space-x-2">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => setViewingQuote(quote)}
                              title="Visualizar"
                            >
                              <Eye className="h-4 w-4 text-primary" />
                            </Button>
                            
                            {quote.status === 'pending' && (
                              <>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  onClick={() => handleUpdateStatus(quote.id, 'approved')}
                                  title="Aprovar"
                                >
                                  <CheckCircle className="h-4 w-4 text-green-500" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  onClick={() => handleUpdateStatus(quote.id, 'rejected')}
                                  title="Rejeitar"
                                >
                                  <XCircle className="h-4 w-4 text-red-500" />
                                </Button>
                              </>
                            )}
                            
                            {quotes && customers && vehicles && (
                              <PDFDownloadLink
                                document={
                                  <QuotePDF 
                                    quote={quote} 
                                    customer={customers.find(c => c.id === quote.customerId)!}
                                    vehicle={vehicles.find(v => v.id === quote.vehicleId)!}
                                  />
                                }
                                fileName={`orcamento_${quote.id.toString().padStart(3, '0')}.pdf`}
                              >
                                {({ loading }) => (
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    disabled={loading}
                                    title="Imprimir PDF"
                                  >
                                    <Printer className="h-4 w-4 text-gray-700" />
                                  </Button>
                                )}
                              </PDFDownloadLink>
                            )}
                            
                            {quote.status === 'approved' && (
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => {
                                  // Navigate to create service
                                  window.location.href = `/services/new?quoteId=${quote.id}&customerId=${quote.customerId}&vehicleId=${quote.vehicleId}`;
                                }}
                                title="Criar Serviço"
                              >
                                <Wrench className="h-4 w-4 text-amber-500" />
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="text-center py-4 text-gray-500">
                        Nenhum orçamento encontrado
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            
            {filteredQuotes.length > 0 && (
              <div className="p-4 border-t border-gray-200 flex justify-between items-center">
                <p className="text-sm text-gray-600">
                  Mostrando <span className="font-medium">{(currentPage - 1) * itemsPerPage + 1}-{Math.min(currentPage * itemsPerPage, filteredQuotes.length)}</span> de <span className="font-medium">{filteredQuotes.length}</span> orçamentos
                </p>
                
                <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious 
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        className={currentPage === 1 ? "opacity-50 cursor-not-allowed" : ""}
                      />
                    </PaginationItem>
                    
                    {Array.from({ length: Math.min(totalPages, 3) }).map((_, i) => {
                      const pageNumber = currentPage <= 2
                        ? i + 1
                        : currentPage >= totalPages - 1
                          ? totalPages - 2 + i
                          : currentPage - 1 + i;
                          
                      if (pageNumber > totalPages) return null;
                      
                      return (
                        <PaginationItem key={i}>
                          <PaginationLink
                            isActive={pageNumber === currentPage}
                            onClick={() => setCurrentPage(pageNumber)}
                          >
                            {pageNumber}
                          </PaginationLink>
                        </PaginationItem>
                      );
                    })}
                    
                    <PaginationItem>
                      <PaginationNext 
                        onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                        className={currentPage === totalPages ? "opacity-50 cursor-not-allowed" : ""}
                      />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              </div>
            )}
          </div>

          <Dialog open={isDialogOpen || !!viewingQuote} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) setViewingQuote(null);
          }}>
            <DialogContent className="sm:max-w-[800px]">
              <DialogHeader>
                <DialogTitle>
                  {viewingQuote ? `Orçamento #${viewingQuote.id.toString().padStart(3, '0')}` : 'Novo Orçamento'}
                </DialogTitle>
              </DialogHeader>
              <QuoteForm 
                quote={viewingQuote} 
                preSelectedVehicleId={selectedVehicleId}
                preSelectedCustomerId={selectedCustomerId}
                readOnly={!!viewingQuote}
                onSuccess={() => {
                  setIsDialogOpen(false);
                  setViewingQuote(null);
                  queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
                  // Clear URL parameters after successful submission
                  window.history.replaceState({}, document.title, window.location.pathname);
                }}
              />
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  );
}
