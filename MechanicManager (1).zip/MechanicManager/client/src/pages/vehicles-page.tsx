import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import VehicleForm from "@/components/vehicles/vehicle-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatLicensePlate } from "@/lib/utils";
import { Vehicle, Customer } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Plus, Search, Pencil, Trash2, FileText } from "lucide-react";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

export default function VehiclesPage() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [manufacturerFilter, setManufacturerFilter] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [customerFilter, setCustomerFilter] = useState<number | null>(null);
  const itemsPerPage = 10;
  const { toast } = useToast();

  // Extract customer ID from URL if available
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const customerId = params.get('customerId');
    if (customerId) {
      setCustomerFilter(parseInt(customerId));
    }
  }, []);

  // Fetch vehicles
  const { data: vehicles, isLoading: vehiclesLoading } = useQuery<Vehicle[]>({
    queryKey: ['/api/vehicles'],
  });

  // Fetch customers for the select dropdown
  const { data: customers } = useQuery<Customer[]>({
    queryKey: ['/api/customers'],
  });

  // Delete vehicle mutation
  const deleteVehicleMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/vehicles/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
      toast({
        title: "Veículo removido",
        description: "Veículo removido com sucesso",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível remover o veículo",
        variant: "destructive",
      });
    }
  });

  // Handle vehicle deletion
  const handleDeleteVehicle = (id: number) => {
    if (window.confirm("Tem certeza que deseja excluir este veículo?")) {
      deleteVehicleMutation.mutate(id);
    }
  };

  // Handle editing vehicle
  const handleEditVehicle = (vehicle: Vehicle) => {
    setEditingVehicle(vehicle);
    setIsDialogOpen(true);
  };

  // Filter vehicles
  const filteredVehicles = vehicles 
    ? vehicles
        .filter(vehicle => 
          (searchTerm === "" || 
            vehicle.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
            vehicle.licensePlate.toLowerCase().includes(searchTerm.toLowerCase())
          ) &&
          (manufacturerFilter === "" || vehicle.manufacturer === manufacturerFilter) &&
          (customerFilter === null || vehicle.customerId === customerFilter)
        )
    : [];

  // Get unique manufacturers for filter
  const manufacturers = vehicles 
    ? Array.from(new Set(vehicles.map(v => v.manufacturer)))
    : [];

  // Paginate vehicles
  const paginatedVehicles = filteredVehicles.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  
  const totalPages = Math.ceil(filteredVehicles.length / itemsPerPage);

  // Find customer names
  const getCustomerName = (customerId: number) => {
    const customer = customers?.find(c => c.id === customerId);
    return customer ? customer.name : 'Cliente não encontrado';
  };

  return (
    <div className="h-screen flex flex-col">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-auto bg-gray-50 p-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Veículos</h2>
              <p className="text-gray-600">Gerenciamento de veículos</p>
            </div>
            
            <Button onClick={() => {
              setEditingVehicle(null);
              setIsDialogOpen(true);
            }}>
              <Plus className="mr-2 h-4 w-4" />
              Novo Veículo
            </Button>
          </div>

          <div className="bg-white rounded-lg shadow">
            <div className="p-4 border-b border-gray-200">
              <div className="flex flex-col sm:flex-row justify-between gap-4">
                <div className="relative flex-grow">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input 
                    placeholder="Buscar veículos..." 
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <div className="flex gap-2 flex-col sm:flex-row">
                  <Select 
                    value={manufacturerFilter} 
                    onValueChange={setManufacturerFilter}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Todos os Fabricantes" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os Fabricantes</SelectItem>
                      {manufacturers.map((manufacturer) => (
                        <SelectItem key={manufacturer} value={manufacturer}>
                          {manufacturer}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {customers && (
                    <Select 
                      value={customerFilter?.toString() || ""} 
                      onValueChange={(value) => setCustomerFilter(value ? parseInt(value) : null)}
                    >
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Todos os Clientes" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos os Clientes</SelectItem>
                        {customers.map((customer) => (
                          <SelectItem key={customer.id} value={customer.id.toString()}>
                            {customer.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </div>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Cliente</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Fabricante</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Modelo</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Ano</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Placa</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {vehiclesLoading ? (
                    <tr>
                      <td colSpan={6} className="text-center py-4">
                        <div className="flex justify-center">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                        </div>
                      </td>
                    </tr>
                  ) : paginatedVehicles.length > 0 ? (
                    paginatedVehicles.map((vehicle) => (
                      <tr key={vehicle.id} className="border-t border-gray-200">
                        <td className="py-3 px-4 text-sm">{getCustomerName(vehicle.customerId)}</td>
                        <td className="py-3 px-4 text-sm">{vehicle.manufacturer}</td>
                        <td className="py-3 px-4 text-sm">{vehicle.model}</td>
                        <td className="py-3 px-4 text-sm">{vehicle.year}</td>
                        <td className="py-3 px-4 text-sm">{formatLicensePlate(vehicle.licensePlate)}</td>
                        <td className="py-3 px-4 text-sm">
                          <div className="flex space-x-2">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => handleEditVehicle(vehicle)}
                              title="Editar"
                            >
                              <Pencil className="h-4 w-4 text-primary" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => handleDeleteVehicle(vehicle.id)}
                              title="Excluir"
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => {
                                // Navigate to create quote
                                window.location.href = `/quotes/new?vehicleId=${vehicle.id}&customerId=${vehicle.customerId}`;
                              }}
                              title="Criar Orçamento"
                            >
                              <FileText className="h-4 w-4 text-amber-500" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="text-center py-4 text-gray-500">
                        Nenhum veículo encontrado
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            
            {filteredVehicles.length > 0 && (
              <div className="p-4 border-t border-gray-200 flex justify-between items-center">
                <p className="text-sm text-gray-600">
                  Mostrando <span className="font-medium">{(currentPage - 1) * itemsPerPage + 1}-{Math.min(currentPage * itemsPerPage, filteredVehicles.length)}</span> de <span className="font-medium">{filteredVehicles.length}</span> veículos
                </p>
                
                <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious 
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                      />
                    </PaginationItem>
                    
                    {Array.from({ length: Math.min(totalPages, 3) }).map((_, i) => {
                      const pageNumber = currentPage <= 2
                        ? i + 1
                        : currentPage >= totalPages - 1
                          ? totalPages - 2 + i
                          : currentPage - 1 + i;
                          
                      if (pageNumber > totalPages) return null;
                      
                      return (
                        <PaginationItem key={i}>
                          <PaginationLink
                            isActive={pageNumber === currentPage}
                            onClick={() => setCurrentPage(pageNumber)}
                          >
                            {pageNumber}
                          </PaginationLink>
                        </PaginationItem>
                      );
                    })}
                    
                    <PaginationItem>
                      <PaginationNext 
                        onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}
                      />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              </div>
            )}
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>
                  {editingVehicle ? 'Editar Veículo' : 'Novo Veículo'}
                </DialogTitle>
              </DialogHeader>
              <VehicleForm 
                vehicle={editingVehicle} 
                preSelectedCustomerId={customerFilter}
                onSuccess={() => {
                  setIsDialogOpen(false);
                  queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
                }}
              />
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  );
}
