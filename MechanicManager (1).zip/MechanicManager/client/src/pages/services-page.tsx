import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import ServiceForm from "@/components/services/service-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/utils";
import { Service, Customer, Vehicle } from "@shared/schema";
import { Plus, Search, Eye, Pencil, Camera, CheckCircle } from "lucide-react";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

export default function ServicesPage() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isUpdateDialogOpen, setIsUpdateDialogOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedQuoteId, setSelectedQuoteId] = useState<number | null>(null);
  const [selectedVehicleId, setSelectedVehicleId] = useState<number | null>(null);
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | null>(null);
  const itemsPerPage = 10;
  const { toast } = useToast();

  // Extract parameters from URL if available
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const quoteId = params.get('quoteId');
    const vehicleId = params.get('vehicleId');
    const customerId = params.get('customerId');
    
    if (quoteId) setSelectedQuoteId(parseInt(quoteId));
    if (vehicleId) setSelectedVehicleId(parseInt(vehicleId));
    if (customerId) setSelectedCustomerId(parseInt(customerId));
    
    // If we have all three, open the service form automatically
    if (quoteId && vehicleId && customerId) {
      setIsDialogOpen(true);
    }
  }, []);

  // Fetch services
  const { data: services, isLoading: servicesLoading } = useQuery<Service[]>({
    queryKey: ['/api/services'],
  });

  // Fetch customers for lookup
  const { data: customers } = useQuery<Customer[]>({
    queryKey: ['/api/customers'],
  });

  // Fetch vehicles for lookup
  const { data: vehicles } = useQuery<Vehicle[]>({
    queryKey: ['/api/vehicles'],
  });

  // Update service status mutation
  const updateServiceStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number, status: string }) => {
      await apiRequest("PATCH", `/api/services/${id}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      toast({
        title: "Status atualizado",
        description: "Status do serviço atualizado com sucesso",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o status do serviço",
        variant: "destructive",
      });
    }
  });

  // Complete service mutation
  const completeServiceMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("PATCH", `/api/services/${id}`, { 
        status: 'completed',
        actualEndDate: new Date().toISOString().split('T')[0]
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      toast({
        title: "Serviço finalizado",
        description: "Serviço finalizado com sucesso",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível finalizar o serviço",
        variant: "destructive",
      });
    }
  });

  // Handle status update
  const handleUpdateStatus = (id: number, status: string) => {
    updateServiceStatusMutation.mutate({ id, status });
  };

  // Handle complete service
  const handleCompleteService = (id: number) => {
    if (window.confirm("Finalizar este serviço?")) {
      completeServiceMutation.mutate(id);
    }
  };

  // Handle view service details
  const handleViewService = (service: Service) => {
    setSelectedService(service);
    setIsDialogOpen(true);
  };

  // Handle update service
  const handleUpdateService = (service: Service) => {
    setSelectedService(service);
    setIsUpdateDialogOpen(true);
  };

  // Filter services
  const filteredServices = services 
    ? services.filter(service => {
        // Match search term against customer or OS number
        const customerMatch = customers?.find(c => c.id === service.customerId)?.name.toLowerCase().includes(searchTerm.toLowerCase());
        const idMatch = service.id.toString().includes(searchTerm);
        
        // Apply filters
        return (searchTerm === "" || customerMatch || idMatch) &&
               (statusFilter === "" || service.status === statusFilter);
      })
    : [];

  // Paginate services
  const paginatedServices = filteredServices.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  
  const totalPages = Math.ceil(filteredServices.length / itemsPerPage);

  // Helper functions
  const getCustomerName = (customerId: number) => {
    const customer = customers?.find(c => c.id === customerId);
    return customer ? customer.name : 'Cliente não encontrado';
  };

  const getVehicleInfo = (vehicleId: number) => {
    const vehicle = vehicles?.find(v => v.id === vehicleId);
    return vehicle ? `${vehicle.manufacturer} ${vehicle.model} (${vehicle.licensePlate})` : 'Veículo não encontrado';
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'in_progress':
        return 'bg-green-100 text-green-800';
      case 'waiting_parts':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      case 'paused':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'in_progress':
        return 'Em Andamento';
      case 'waiting_parts':
        return 'Aguardando Peças';
      case 'completed':
        return 'Finalizado';
      case 'paused':
        return 'Pausado';
      default:
        return 'Desconhecido';
    }
  };

  return (
    <div className="h-screen flex flex-col">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-auto bg-gray-50 p-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Serviços em Andamento</h2>
              <p className="text-gray-600">Acompanhamento de serviços</p>
            </div>
            
            <Button onClick={() => {
              setSelectedService(null);
              setIsDialogOpen(true);
            }}>
              <Plus className="mr-2 h-4 w-4" />
              Novo Serviço
            </Button>
          </div>

          <div className="bg-white rounded-lg shadow">
            <div className="p-4 border-b border-gray-200">
              <div className="flex flex-col sm:flex-row justify-between gap-4">
                <div className="relative flex-grow">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input 
                    placeholder="Buscar serviços..." 
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <div className="flex gap-2">
                  <Select 
                    value={statusFilter} 
                    onValueChange={setStatusFilter}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Todos os Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os Status</SelectItem>
                      <SelectItem value="in_progress">Em Andamento</SelectItem>
                      <SelectItem value="waiting_parts">Aguardando Peças</SelectItem>
                      <SelectItem value="paused">Pausado</SelectItem>
                      <SelectItem value="completed">Finalizado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">OS Nº</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Data Entrada</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Cliente</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Veículo</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Status</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Previsão</th>
                    <th className="py-3 px-4 text-left text-sm font-medium text-gray-600">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {servicesLoading ? (
                    <tr>
                      <td colSpan={7} className="text-center py-4">
                        <div className="flex justify-center">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                        </div>
                      </td>
                    </tr>
                  ) : paginatedServices.length > 0 ? (
                    paginatedServices.map((service) => (
                      <tr key={service.id} className="border-t border-gray-200">
                        <td className="py-3 px-4 text-sm">OS{service.id.toString().padStart(3, '0')}</td>
                        <td className="py-3 px-4 text-sm">{formatDate(service.startDate)}</td>
                        <td className="py-3 px-4 text-sm">{getCustomerName(service.customerId)}</td>
                        <td className="py-3 px-4 text-sm">{getVehicleInfo(service.vehicleId)}</td>
                        <td className="py-3 px-4 text-sm">
                          <span className={`px-2 py-1 rounded-full text-xs ${getStatusBadgeClass(service.status)}`}>
                            {getStatusText(service.status)}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-sm">{formatDate(service.estimatedEndDate)}</td>
                        <td className="py-3 px-4 text-sm">
                          <div className="flex space-x-2">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => handleViewService(service)}
                              title="Detalhes"
                            >
                              <Eye className="h-4 w-4 text-primary" />
                            </Button>
                            
                            {service.status !== 'completed' && (
                              <>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  onClick={() => handleUpdateService(service)}
                                  title="Atualizar"
                                >
                                  <Pencil className="h-4 w-4 text-green-500" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  onClick={() => { setIsUpdateDialogOpen(true); setSelectedService(service); }}
                                  title="Fotos"
                                >
                                  <Camera className="h-4 w-4 text-amber-500" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  onClick={() => handleCompleteService(service.id)}
                                  title="Finalizar"
                                >
                                  <CheckCircle className="h-4 w-4 text-gray-700" />
                                </Button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="text-center py-4 text-gray-500">
                        Nenhum serviço encontrado
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            
            {filteredServices.length > 0 && (
              <div className="p-4 border-t border-gray-200 flex justify-between items-center">
                <p className="text-sm text-gray-600">
                  Mostrando <span className="font-medium">{(currentPage - 1) * itemsPerPage + 1}-{Math.min(currentPage * itemsPerPage, filteredServices.length)}</span> de <span className="font-medium">{filteredServices.length}</span> serviços
                </p>
                
                <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious 
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        className={currentPage === 1 ? "opacity-50 cursor-not-allowed" : ""}
                      />
                    </PaginationItem>
                    
                    {Array.from({ length: Math.min(totalPages, 3) }).map((_, i) => {
                      const pageNumber = currentPage <= 2
                        ? i + 1
                        : currentPage >= totalPages - 1
                          ? totalPages - 2 + i
                          : currentPage - 1 + i;
                          
                      if (pageNumber > totalPages) return null;
                      
                      return (
                        <PaginationItem key={i}>
                          <PaginationLink
                            isActive={pageNumber === currentPage}
                            onClick={() => setCurrentPage(pageNumber)}
                          >
                            {pageNumber}
                          </PaginationLink>
                        </PaginationItem>
                      );
                    })}
                    
                    <PaginationItem>
                      <PaginationNext 
                        onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                        className={currentPage === totalPages ? "opacity-50 cursor-not-allowed" : ""}
                      />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              </div>
            )}
          </div>

          {/* New/View Service Dialog */}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="sm:max-w-[800px]">
              <DialogHeader>
                <DialogTitle>
                  {selectedService ? `Serviço OS${selectedService.id.toString().padStart(3, '0')}` : 'Novo Serviço'}
                </DialogTitle>
              </DialogHeader>
              <ServiceForm 
                service={selectedService} 
                preSelectedQuoteId={selectedQuoteId}
                preSelectedVehicleId={selectedVehicleId}
                preSelectedCustomerId={selectedCustomerId}
                readOnly={!!selectedService}
                onSuccess={() => {
                  setIsDialogOpen(false);
                  setSelectedService(null);
                  queryClient.invalidateQueries({ queryKey: ['/api/services'] });
                  // Clear URL parameters after successful submission
                  window.history.replaceState({}, document.title, window.location.pathname);
                }}
              />
            </DialogContent>
          </Dialog>

          {/* Update Service Dialog */}
          <Dialog open={isUpdateDialogOpen} onOpenChange={setIsUpdateDialogOpen}>
            <DialogContent className="sm:max-w-[800px]">
              <DialogHeader>
                <DialogTitle>
                  Atualizar Serviço OS{selectedService?.id.toString().padStart(3, '0')}
                </DialogTitle>
              </DialogHeader>
              {selectedService && (
                <ServiceForm 
                  service={selectedService}
                  isUpdate={true}
                  onSuccess={() => {
                    setIsUpdateDialogOpen(false);
                    setSelectedService(null);
                    queryClient.invalidateQueries({ queryKey: ['/api/services'] });
                  }}
                />
              )}
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  );
}
