import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import StatusCard from "@/components/dashboard/status-card";
import RecentServices from "@/components/dashboard/recent-services";
import RecentQuotes from "@/components/dashboard/recent-quotes";
import { Loader2 } from "lucide-react";

interface DashboardStats {
  customerCount: number;
  vehicleCount: number;
  pendingQuoteCount: number;
  activeServiceCount: number;
  recentServices: any[];
  recentQuotes: any[];
}

export default function HomePage() {
  const { data: stats, isLoading, error } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
  });

  return (
    <div className="h-screen flex flex-col">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-auto bg-gray-50 p-4">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
            <p className="text-gray-600">Resumo das atividades da oficina</p>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : error ? (
            <div className="bg-red-50 text-red-500 p-4 rounded-md">
              Erro ao carregar estatísticas do dashboard
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                <StatusCard 
                  title="Total de Clientes" 
                  value={stats?.customerCount || 0} 
                  icon="users" 
                  color="primary" 
                />
                <StatusCard 
                  title="Veículos Cadastrados" 
                  value={stats?.vehicleCount || 0} 
                  icon="car" 
                  color="secondary" 
                />
                <StatusCard 
                  title="Orçamentos Pendentes" 
                  value={stats?.pendingQuoteCount || 0} 
                  icon="file" 
                  color="warning" 
                />
                <StatusCard 
                  title="Serviços em Andamento" 
                  value={stats?.activeServiceCount || 0} 
                  icon="tools" 
                  color="success" 
                />
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <RecentServices services={stats?.recentServices || []} />
                <RecentQuotes quotes={stats?.recentQuotes || []} />
              </div>
            </>
          )}
        </main>
      </div>
    </div>
  );
}
